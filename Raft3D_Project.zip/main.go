package main

import (
	"log"
	"net/http"
	"os"
	"raft3d/api"
	"raft3d/raftnode"
)

func main() {
	nodeID := os.Args[1]
	bindAddr := os.Args[2]
	raftDir := os.Args[3]
	peers := os.Args[4:]

	r, fsm := raftnode.NewRaftNode(nodeID, bindAddr, raftDir, peers)
	go api.StartServer(fsm.Store, ":"+bindAddr[len("127.0.0.1:"):])

	select {}
}
